/* ===========================================================
   EDIT THIS FILE to change words, jobs and programs.
   No other file needs to change for content updates.
   =========================================================== */

window.JA_CONFIG = {
  retakeUrl: "#",            // link for the "Try the survey again" button
  showScores: false,         // true = also show "Score: 83 of 100" on the meters
  bandNames: ["Getting started", "Building", "Strong"]
};

/* One entry per survey. {K} and {D} in the story text are replaced with these phrases. */
window.JA_SURVEYS = {
  entre: {
    name: "Entrepreneurship",
    K: "how businesses are started",     D: "teamwork and resilience",
    kSub: "How ventures are started and run",
    dSub: "Skills like communication, teamwork and resilience"
  },
  work: {
    name: "Work Readiness",
    K: "career planning",                D: "workplace skills",
    kSub: "Planning a career and setting goals",
    dSub: "Skills like communication and problem solving"
  },
  fin: {
    name: "Financial Capability",
    K: "financial decisions",            D: "money habits and communication",
    kSub: "Making smart choices with money",
    dSub: "Habits like planning ahead, speaking up and bouncing back"
  }
};

/* Nine archetypes. Key = Knowledge band + Durable Skills band (0 Getting started, 1 Building, 2 Strong). */
window.JA_ARCHETYPES = {
  "22": { name: "The Ace", tag: "You know it and you can do it.",
    story: "Right now you know {K} well and you put it into practice with {D}. That mix is rare and powerful. People like you often become the one others turn to when a plan has to turn into action.",
    strengths: ["You understand {K}", "You show strong {D}", "You turn plans into action"],
    grow: "Stretch yourself by mentoring others or leading a bigger project." },
  "21": { name: "The Scholar", tag: "You understand how things work.",
    story: "Right now {K} is your strongest area. You understand how things work, and your {D} are still building. With practice in real situations, what you know can turn into what you do.",
    strengths: ["You understand {K}", "You learn quickly", "You see the big picture"],
    grow: "Practice your {D} in real, hands-on situations." },
  "20": { name: "The Thinker", tag: "You have strong know-how and a head start.",
    story: "Right now you have strong know-how in {K}. Your {D} are just getting started, which is a normal place to begin. Trying ideas out with other people is the fastest way to grow them.",
    strengths: ["You understand {K}", "You think things through", "You ask good questions"],
    grow: "Start building your {D} by working with a team." },
  "12": { name: "The Doer", tag: "You act, adapt and get things moving.",
    story: "Right now your {D} lead the way. You act, adapt and work well with others, while your knowledge of {K} keeps building. A little more learning will take your actions even further.",
    strengths: ["You show strong {D}", "You adapt and keep going", "You work well with others"],
    grow: "Build your knowledge of {K}." },
  "11": { name: "The Climber", tag: "You are growing in two areas at once.",
    story: "Right now you are growing in both {K} and {D}. You are not starting from zero, and each new experience adds to both. Steady growth in two areas adds up quickly.",
    strengths: ["You are growing in two areas at once", "You are open to feedback", "You keep moving forward"],
    grow: "Pick one area, {K} or {D}, to push further this season." },
  "10": { name: "The Learner", tag: "You are curious and ready to learn.",
    story: "Right now you are building your knowledge of {K}, and your {D} are just getting started. You are curious and open to learning. One hands-on experience can move both areas forward.",
    strengths: ["You are building knowledge of {K}", "You are curious", "You are ready to learn"],
    grow: "Try one hands-on activity to start building your {D}." },
  "02": { name: "The Natural", tag: "You have strong instincts.",
    story: "Right now your {D} are a clear strength, even though {K} is still ahead of you. Many people with strong instincts only need to learn the language and tools to match.",
    strengths: ["You show strong {D}", "You have good instincts", "You stay calm and adapt"],
    grow: "Learn the basics of {K} to match your instincts." },
  "01": { name: "The Go-Getter", tag: "You are ready to move.",
    story: "Right now your {D} are building and you are ready to move. Knowledge of {K} is the next step. Pair your drive with a bit of learning and you will take off.",
    strengths: ["You show growing {D}", "You take initiative", "You are willing to try"],
    grow: "Build your knowledge of {K}." },
  "00": { name: "The Starter", tag: "Every journey begins here, and every step counts.",
    story: "Right now you are at the start of your journey in {K} and {D}. Everyone begins here, and every step counts. The best next move is one small, hands-on experience.",
    strengths: ["You finished the survey", "You are open to something new", "Every area is open for growth"],
    grow: "Pick one small, hands-on experience in {K} or {D}." }
};

/* Jobs to explore. Group is chosen from the two bands:
   knowledge = Knowledge band higher, skills = Durable Skills band higher,
   balanced = equal and Building or Strong, starter = both Getting started. */
window.JA_JOBS = {
  entre: {
    knowledge: ["Market researcher", "Business analyst", "Startup strategist", "Product manager"],
    skills:    ["Co-founder", "Sales lead", "Event organizer", "Operations coordinator"],
    balanced:  ["Entrepreneur", "Product designer", "Small business owner", "Consultant"],
    starter:   ["Pop-up shop helper", "Community project leader", "Junior marketer", "Peer tutor"]
  },
  work: {
    knowledge: ["Career counselor", "HR specialist", "Project planner", "Training coordinator"],
    skills:    ["Team lead", "Customer success rep", "Skilled trades apprentice", "Healthcare assistant"],
    balanced:  ["Project manager", "Technician", "Teacher", "Analyst"],
    starter:   ["Intern", "Retail associate", "Camp counselor", "Volunteer coordinator"]
  },
  fin: {
    knowledge: ["Financial analyst", "Accountant", "Bank officer", "Economist"],
    skills:    ["Budget coach", "Tax-prep assistant", "Community banker", "Bookkeeper"],
    balanced:  ["Financial planner", "Investment associate", "Fintech specialist", "Nonprofit finance lead"],
    starter:   ["Savings group leader", "Peer money mentor", "Cashier", "Bookkeeping trainee"]
  }
};

/* JA programs. PLACEHOLDER names: confirm with JA and add real links.
   k = shown when Knowledge is the area to grow, d = Durable Skills, stretch = both Strong. */
window.JA_PROGRAMS = {
  entre: {
    k: { name: "JA Be Entrepreneurial", why: "Learn how ideas become real businesses, step by step.", url: "#" },
    d: { name: "JA Company Program", why: "Start and run a mini company with a team of students.", url: "#" },
    stretch: { name: "JA Company Program (team lead)", why: "Lead a team and mentor younger students.", url: "#" }
  },
  work: {
    k: { name: "JA Career Success", why: "Practice setting goals and planning your path to a job.", url: "#" },
    d: { name: "JA Job Shadow", why: "See real workplaces and practice workplace skills.", url: "#" },
    stretch: { name: "JA Job Shadow (mentor)", why: "Help other students prepare for their first job.", url: "#" }
  },
  fin: {
    k: { name: "JA Economics for Success", why: "Learn how to make smart choices with money.", url: "#" },
    d: { name: "JA Finance Park", why: "Practice real money decisions in a hands-on simulation.", url: "#" },
    stretch: { name: "JA Finance Park (peer mentor)", why: "Coach other students through money decisions.", url: "#" }
  }
};

/* "What you told us": the four self-report metrics. */
window.JA_TOLD = [
  { key: "mindset",     title: "Mindset",     desc: "How you feel about new ideas and opportunities." },
  { key: "confidence",  title: "Confidence",  desc: "How sure you are that you can reach your goals." },
  { key: "plans",       title: "Plans",       desc: "What you plan to do in the next few months." },
  { key: "connections", title: "Connections", desc: "The people and programs you can lean on." }
];
