(function () {
  "use strict";
  var C = window.JA_CONFIG, SURVEYS = window.JA_SURVEYS, ARCH = window.JA_ARCHETYPES,
      JOBS = window.JA_JOBS, PROGRAMS = window.JA_PROGRAMS, TOLD = window.JA_TOLD;
  var $ = function (id) { return document.getElementById(id); };
  var params = new URLSearchParams(window.location.search);

  /* ---------- helpers ---------- */
  function el(tag, cls, text) {
    var n = document.createElement(tag);
    if (cls) n.className = cls;
    if (text !== undefined) n.textContent = text;   // textContent keeps URL values safe
    return n;
  }
  function clamp(n, lo, hi) { return Math.min(hi, Math.max(lo, n)); }
  function num(name) {
    var v = parseFloat(params.get(name));
    return isNaN(v) ? null : v;
  }
  // Score can arrive as 0-100 (k=83) or as raw points (k=5&kmax=6).
  function score(name) {
    var v = num(name);
    if (v === null) return null;
    var max = num(name + "max");
    return clamp(max ? (v / max) * 100 : v, 0, 100);
  }
  function fill(text, s) {
    return text.replace(/\{K\}/g, s.K).replace(/\{D\}/g, s.D);
  }
  function bandOf(value, cut) { return value < cut[0] ? 0 : value < cut[1] ? 1 : 2; }
  function levelWord(v) { return v >= 4 ? "High" : v >= 3 ? "Medium" : "Still building"; }

  /* ---------- inputs ---------- */
  var hasParams = params.has("k") || params.has("d");
  var survey = params.get("survey");
  if (!SURVEYS[survey]) survey = "work";
  var S = SURVEYS[survey];

  var input = {
    k: hasParams ? score("k") : 83,
    d: hasParams ? score("d") : 52,
    country: params.get("country") || (hasParams ? "" : "Kenya"),
    region: params.get("region") || (hasParams ? "" : "Africa"),
    year: params.get("year") || "2027",
    n: num("n") || (hasParams ? null : 14203),
    told: {
      mindset: params.has("mindset") ? num("mindset") : (hasParams ? null : 4.2),
      confidence: params.has("confidence") ? num("confidence") : (hasParams ? null : 3.1),
      plans: params.has("plans") ? num("plans") : (hasParams ? null : 4.0),
      connections: params.has("connections") ? num("connections") : (hasParams ? null : 3.0)
    }
  };
  if (!hasParams) $("demoBanner").hidden = false;

  /* ---------- held-back state ---------- */
  if (params.get("flag") === "pattern" || input.k === null || input.d === null) {
    $("heldback").hidden = false;
    $("retakeBtn").href = params.get("retake") && /^https:\/\//.test(params.get("retake")) ? params.get("retake") : C.retakeUrl;
    wireSave();
    return;
  }

  /* ---------- cutoffs, then render ---------- */
  fetch("data/cutoffs.json").then(function (r) { return r.json(); })
    .catch(function () { return { default: { entre: { k: [40, 70], d: [40, 70] }, work: { k: [40, 70], d: [40, 70] }, fin: { k: [40, 70], d: [40, 70] } } }; })
    .then(render);

  function render(table) {
    var cc = (table.countries && table.countries[input.country] && table.countries[input.country][survey]) || {};
    var def = table.default[survey];
    var kCut = cc.k || def.k, dCut = cc.d || def.d;
    var kb = bandOf(input.k, kCut), db = bandOf(input.d, dCut);
    var a = ARCH["" + kb + db];
    var names = C.bandNames;
    var place = input.country || "your peer group";

    document.title = "Your result: " + a.name + " | JA Institute";
    $("heroEyebrow").textContent = S.name + " survey";
    $("archName").textContent = a.name;
    $("archTag").textContent = a.tag;

    // badges
    var badges = $("badges");
    if (input.country) {
      var line = input.n
        ? "One of " + input.n.toLocaleString("en-US") + " youth from " + input.country + " in the " + input.year + " class"
        : "Youth from " + input.country + ", " + input.year + " class";
      badges.appendChild(el("span", "chip", line));
    }
    if (input.region) badges.appendChild(el("span", "chip chip-alt", input.region));

    // tiles
    var tiles = $("tiles");
    [["Knowledge", names[kb]], ["Durable Skills", names[db]], ["Survey", S.name]].forEach(function (t) {
      var d = el("div", "tile");
      d.appendChild(el("div", "k", t[0]));
      d.appendChild(el("div", "v", t[1]));
      tiles.appendChild(d);
    });

    // story
    $("storyText").textContent = fill(a.story, S);

    // meters
    $("standingSub").textContent = "Compared with youth in " + place + ". These are bands, not ranks.";
    var meters = $("meters");
    [["Knowledge", S.kSub, kb, input.k], ["Durable Skills", S.dSub, db, input.d]].forEach(function (m) {
      var box = el("div", "meter");
      var head = el("div", "meter-head");
      head.appendChild(el("h3", "", m[0]));
      head.appendChild(el("span", "", m[1]));
      box.appendChild(head);
      var segs = el("div", "segs");
      names.forEach(function (nm, i) {
        var s = el("div", "seg" + (i === m[2] ? " on" : ""), nm);
        if (i === m[2]) s.setAttribute("aria-label", "Your band: " + nm);
        segs.appendChild(s);
      });
      box.appendChild(segs);
      var cap = el("p", "meter-cap");
      cap.appendChild(document.createTextNode("You are in the "));
      cap.appendChild(el("strong", "", names[m[2]]));
      cap.appendChild(document.createTextNode(" band among youth in " + place + "." +
        (C.showScores ? " Score: " + Math.round(m[3]) + " of 100." : "")));
      box.appendChild(cap);
      meters.appendChild(box);
    });

    // told
    var grid = $("toldGrid");
    TOLD.forEach(function (t) {
      var v = input.told[t.key];
      var box = el("div", "told");
      box.appendChild(el("h3", "", t.title));
      box.appendChild(el("p", "d", t.desc));
      if (v === null) {
        box.appendChild(el("p", "lvl", "No answer"));
      } else {
        box.appendChild(el("p", "lvl", "You said: " + levelWord(v)));
        var dots = el("div", "dots");
        dots.setAttribute("aria-hidden", "true");
        for (var i = 1; i <= 5; i++) dots.appendChild(el("span", "dot" + (i <= Math.round(v) ? " f" : "")));
        box.appendChild(dots);
      }
      grid.appendChild(box);
    });

    // strengths + grow
    var ul = $("strengths");
    a.strengths.forEach(function (s) { ul.appendChild(el("li", "", fill(s, S))); });
    $("growText").textContent = fill(a.grow, S);

    // jobs
    var group = kb > db ? "knowledge" : db > kb ? "skills" : (kb === 0 ? "starter" : "balanced");
    var jl = $("jobs");
    JOBS[survey][group].forEach(function (j) { jl.appendChild(el("li", "", j)); });

    // program
    var P = PROGRAMS[survey];
    var prog = (kb === 2 && db === 2) ? P.stretch : (kb <= db ? P.k : P.d);
    $("programName").textContent = prog.name;
    $("programWhy").textContent = prog.why;
    $("programLink").href = prog.url;

    $("result").hidden = false;
    wireSave();
  }

  /* ---------- save buttons ---------- */
  function wireSave() {
    $("savePdf").addEventListener("click", function () { window.print(); });
    $("saveImg").addEventListener("click", function () {
      if (!window.html2canvas) { window.print(); return; }
      var target = $("report");
      window.html2canvas(target, { backgroundColor: "#FBFDFD", scale: 2, useCORS: true }).then(function (canvas) {
        var link = document.createElement("a");
        link.download = "my-ja-result.png";
        link.href = canvas.toDataURL("image/png");
        link.click();
      });
    });
  }
})();
