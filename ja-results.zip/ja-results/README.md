# JA Youth Results Page

One scrolling page that shows a student their own result: archetype story, two band meters,
"What you told us", strengths, jobs and a JA program. No build step. Plain HTML, CSS and JS.

## Files
- `index.html`        page structure
- `css/style.css`     JA branding (Montserrat, JA palette, Real-World Red accent)
- `js/data.js`        ALL words: archetypes, jobs, programs. Edit here.
- `js/app.js`         reads the web address and fills the page
- `data/cutoffs.json` yearly band cutoffs per country and survey
- `assets/`           put `logo.svg` here

## Publish on GitHub Pages
1. Create a free GitHub account, then click New repository. Name it `ja-results`. Keep it Public. Create it.
2. On the repo page click "uploading an existing file". Drag in everything from this folder
   (index.html, css, js, data, assets, .nojekyll). Click Commit changes.
3. Go to Settings, then Pages. Under Build and deployment choose Source: "Deploy from a branch",
   Branch: `main`, folder `/ (root)`. Save.
4. Wait about a minute. Your site is at `https://YOUR-USERNAME.github.io/ja-results/`.

Command line instead:
```
git init
git add .
git commit -m "Results page"
git branch -M main
git remote add origin https://github.com/YOUR-USERNAME/ja-results.git
git push -u origin main
```

## See every version of the page
Open the site with no extras to see a sample. Add these to the address to test others:

| What you want to see | Address ending |
|---|---|
| Work Readiness, Strong + Building (The Scholar) | `?survey=work&k=83&d=52&country=Kenya&region=Africa&year=2027&n=14203&mindset=4.2&confidence=3.1&plans=4&connections=3` |
| Entrepreneurship, The Ace | `?survey=entre&k=95&d=90&country=Brazil` |
| Financial Capability, The Starter | `?survey=fin&k=10&d=20&country=Peru` |
| Raw points instead of 0-100 | `?survey=fin&k=2&kmax=6&d=5&dmax=6` |
| Held-back state (same answers everywhere) | `?flag=pattern` |

Bands with the sample cutoffs: under 40 = Getting started, 40 to 69 = Building, 70 and up = Strong.

## Connect Qualtrics
1. In the survey, use Scoring to make two categories: Knowledge and Durable Skills (right-or-wrong questions only).
2. In Survey Flow, add Embedded Data fields: `survey`, `k`, `kmax`, `d`, `dmax`, `country`, `region`, `year`,
   `mindset`, `confidence`, `plans`, `connections` (the last four are the average 1-5 rating of each self-report block).
   Set `k` and `d` to the category scores and `kmax` and `dmax` to the max scores.
3. Optional: set `flag` to `pattern` when a student gives the same answer to everything.
4. End of Survey, Customize, "Override survey end with a redirect". Use:
```
https://YOUR-USERNAME.github.io/ja-results/?survey=${e://Field/survey}&k=${e://Field/k}&kmax=${e://Field/kmax}&d=${e://Field/d}&dmax=${e://Field/dmax}&country=${e://Field/country}&region=${e://Field/region}&year=${e://Field/year}&mindset=${e://Field/mindset}&confidence=${e://Field/confidence}&plans=${e://Field/plans}&connections=${e://Field/connections}&flag=${e://Field/flag}
```
5. Never put a name, email or student ID in the address.

## Yearly update
Export scores, work out the Getting started / Building / Strong cutoffs for each country, edit `data/cutoffs.json`, commit.

## Before launch
- Replace the placeholder JA program names and links in `js/data.js`.
- Add the real logo at `assets/logo.svg` and swap it into the header in `index.html`.
- Archetype names, stories and jobs are drafts for the education team.
